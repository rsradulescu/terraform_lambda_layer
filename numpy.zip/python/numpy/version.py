
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.19.4'
version = '1.19.4'
full_version = '1.19.4'
git_revision = '6d7b8aaed5ae9f0435764675ebac8c9ada06738f'
release = True

if not release:
    version = full_version
